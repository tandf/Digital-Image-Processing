### im2jpeg_lpc.m jpeg2im_lpc.m
使用lpc压缩直流分量带jpeg压缩、解压算法

### main.m 
对RGB图像进行压缩，并转到YCbCr空间进行压缩，显示不同quality下的压缩比、rmse。
